<template>
    <header class="bg-transparent fixed top-0 left-0 w-full z-10 flex items-center">
            <div class="container">
                <div class="flex items-center justify-between relative">
                    <div class="px-4">
                        <a href="#" class="font-bold text-lg text-dasar block py-6">loremipsum</a>
                    </div>
                    <div class="flex items-center px-4">
                        <button  id="humberger" type="button" name="humberger" class="block absolute right-4">
                            <span class="humberger-line transition origin-top-left duration-300 ease-in-out"></span>
                            <span class="humberger-line transition duration-300 ease-in-out"></span>
                            <span class="humberger-line transition origin-bottom-left duration-300 ease-in-out"></span>
                        </button>
                    </div>
                </div>
            </div>
        </header>
</template>