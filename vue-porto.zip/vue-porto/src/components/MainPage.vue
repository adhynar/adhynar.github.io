<template>
    <div>
        <header-section></header-section>
        <hero-section></hero-section>
        <about-me></about-me>
        <project-section></project-section>
    </div>
</template>

<script>
    import HeaderSection from './HeaderSection.vue';
    import HeroSection from './HeroSection.vue';
    import AboutMe from './AboutMe.vue'
    import ProjectSection from './ProjectSection.vue';
    export default{
        components: {
            HeaderSection,
            HeroSection,
            AboutMe, 
            ProjectSection
        }
    }
</script>