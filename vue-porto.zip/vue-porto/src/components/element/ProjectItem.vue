<template>
    <div class=" rounded-sm bg-slate-300">
        <div class="w-full h-1/2">
            <img :src="project.image" alt="" class=" rounded-t-sm w-full h-full object-cover">
        </div>
        <div class="w-full h-1/2 p-3 overflow-x-auto">
            <h2 class="font-semibold text-2xl mb-2">{{ project.name }}</h2>
            <p>{{ project.description }}</p>
        </div>
    </div>
</template>

<script>
    export default{
        props: ['project']
    }
</script>