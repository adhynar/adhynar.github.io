<template>
    <section id="section" class="pt-26 pb-32">
        <div>
            <h3 class="font-semibold text-2xl text-center mb-5">Portofolio</h3>
            <div class="flex flex-row p-3 overflow-y-scroll gap-5">
                <project-item class="w-[300px] h-[300px] min-w-[300px] min-h-[300px] lg:w-[450px] lg:h-[450px] lg:min-w-[450px] lg:min-h-[450px] border-2 border-slate-400/50 rounded-sm" v-for="project in projects" :key="project" v-bind:project="project"></project-item>
            </div>
        </div>
    </section>
</template>

<script>
    import ProjectItem from './element/ProjectItem.vue'

    export default{
        components: {
            ProjectItem
        },
        data(){
            return {
                projects: [
                    {
                        id: 'ubaya-inventory',
                        name: 'Sistem Informasi Gudang Universitas Surabaya',
                        description: 'Website yang dibuat sebagai sistem informasi keluar masuk barang inventaris yang disimpan pada gudang di Universitas Surabaya.',
                        stacks: ['PHP', 'Javascript', 'Bootstrap', 'MySQL'],
                        link: '',
                        image: 'https://placehold.co/600x400',
                    }, 
                    {
                        id: 'oasis-pool',
                        name: 'Website Oasis Pool',
                        description: 'Website yang berfungsi untuk mencatat berbagai macam transaksi, Hutang karyawan atau perusahaan, Transfer bank dan lain-lain yang berhubungan dengan operasional Oasis Pool',
                        stacks: ['Laravel', 'Javascript', 'Jquery', 'Bootstrap', 'MySQL'],
                        link: 'https://oasis.anggaawproject.site/',
                        image: "/public/images/oasis-hero.jpg" 
                    },
                    {
                        id: 'inventory-app',
                        name: 'Inventory App',
                        description: 'Website ini adalah hasil pembaruan pribadi berdasarkan website Sistem Informasi Gudang Universitas Surabaya. Saya mencoba untuk membuat website serupa dengan menggunakan framework Laravel yang sebelumnya saya menggunakan PHP murni.',
                        stacks: ['Laravel', 'Javascript', 'Jquery', 'Bootstrap', 'MySQL'],
                        link: "https://inventory.anggaawproject.site/",
                        image: "/public/images/inventory-hero.jpg"
                    }
                ]      
            }
        }
    }
</script>