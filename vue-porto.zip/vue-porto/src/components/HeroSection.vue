<template>
    <section id="home" class="pt-36">
            <div>
                <div class="flex flex-wrap">
                    <div class="w-full self-center px-4 lg:w-1/2" >
                        <h1 class="text-base font-semibold md:text-xl mb-2" >Salam kenal dari saya <span class="block font-bold text-4xl text-red-500">Angga Adhitya Widjanarko</span></h1>
                        <h2 class="font-medium text-red-500 text-lg mb-5 lg:text-2xl">IT Support, Web Developer <span class="text-slate-500">&</span> <span class="text-slate-800">Technical Support</span></h2>
                        <p class="font-medium text-slate-500 mb-10 leading-relaxed lg:text-xl">Berpengalaman di bidang IT dan Teknik Elektro.</p>
                    </div>
                    <div class="w-full self-end px-4 lg:w-1/2">
                        <div class="mt-10 relative lg:right-0 lg:mt-0" >
                            <img class="max-w-full mx-auto" src="" alt="">
                            <span class="absolute -bottom-16 -z-10 left-1/2 -translate-x-1/2 md:-bottom-4 lg:-bottom-3">
                                <svg width="350" height="350" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                    <path fill="#ef4444" d="M46.2,-79C59.5,-72.3,69.8,-59.3,75.8,-45C81.8,-30.8,83.7,-15.4,82.2,-0.9C80.6,13.6,75.8,27.3,65.8,34.7C55.9,42.2,40.8,43.5,29,45.4C17.2,47.4,8.6,50,-3.9,56.7C-16.3,63.4,-32.7,74.2,-44.7,72.3C-56.6,70.4,-64.3,56,-72.3,41.8C-80.3,27.7,-88.8,13.8,-84.1,2.7C-79.4,-8.4,-61.5,-16.8,-51.8,-28C-42,-39.1,-40.4,-53.1,-33.1,-63.2C-25.8,-73.3,-12.9,-79.6,1.8,-82.7C16.4,-85.8,32.9,-85.6,46.2,-79Z" transform="translate(100 100)" />
                                  </svg>
                            </span>
                        </div>
                    </div>
                </div>
            </div>    
        </section>
</template>